#include "LanParty.h"

void addAtBeginning(Node** head, Teams t) {
    Node* newNode = (Node*)malloc(sizeof(Node));
          newNode->team = t;
          newNode->next = *head;
    
          *head = newNode;
}

void removeLowest(Node** head) {
    if (*head == NULL) return;

    Node *temp = *head;
    float min_score = temp->team.score;

    while (temp != NULL) {
        if (temp->team.score < min_score) {
            min_score = temp->team.score;
        }
        temp = temp->next;
    }

    temp = *head;
    Node *prev = NULL;

    while (temp != NULL) {
        if (temp->team.score == min_score) {
            if (prev == NULL) {
                *head = temp->next;
            } else {
                prev->next = temp->next;
            }
            free(temp);
            return; 
        }
        prev = temp;
        temp = temp->next;
    }
}