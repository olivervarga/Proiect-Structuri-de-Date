#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Player{
char* FirstName;
char* SecondName;
int points;
}Player;

typedef struct Teams{
char* name;
int number_of_players;
float score;
Player* players;
}Teams;

typedef struct Node{
    Teams team;
    struct Node* next;
}Node;


void addAtBeginning(Node** head, Teams t);
void removeLowest(Node** head);
